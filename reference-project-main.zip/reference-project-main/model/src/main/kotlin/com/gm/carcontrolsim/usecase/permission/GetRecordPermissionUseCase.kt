package com.gm.carcontrolsim.usecase.permission

import com.gm.carcontrolsim.entity.PermissionStatus
import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.gateway.RecordPermissionGateway
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.transform
import javax.inject.Inject

// Actually, Permission can be implemented into the Activity.
// This is just to show how UseCase can be designed and implemented.
class GetRecordPermissionUseCase @Inject constructor(
    private val recordPermissionGateway: RecordPermissionGateway,
) {

    // This is just sample code to show how to use Kotlin Flow in Gateway pattern.
    fun getRecordPermissionWithFlow(): Flow<Response<PermissionStatus>> =
        recordPermissionGateway.getRecordPermissionStatusWithFlow()

    fun getRecordPermission(): Response<PermissionStatus> =
        recordPermissionGateway.getRecordPermissionStatus()
}
