package com.gm.carcontrolsim.domain.permission

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.gm.carcontrolsim.entity.PermissionStatus
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class AndroidPermissionDataSource @Inject constructor(
    @ApplicationContext private val context: Context
) : PermissionDataSource {
    override fun getRecordPermission(): PermissionStatus {
        Log.i("AndroidPermissionDataSource", "getRecordPermission")
        val permission = Manifest.permission.RECORD_AUDIO
        val permissionValue =
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        return PermissionStatus(
            permission,
            permissionValue == PackageManager.PERMISSION_GRANTED,
            permissionValue)
    }
}
