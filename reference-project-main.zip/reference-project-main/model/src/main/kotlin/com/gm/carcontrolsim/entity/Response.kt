/*
 * Copyright (C) GM Global Technology Operations LLC 2024.
 * All Rights Reserved.
 * GM Confidential Restricted.
 */

package com.gm.carcontrolsim.entity

sealed class Response<out T : Any> {
    data class Success<out T : Any>(val value: T) : Response<T>()
    data class Error(val reason: String) : Response<Nothing>()
}
