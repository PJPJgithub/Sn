package com.gm.carcontrolsim.usecase.stt

import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.entity.SpeechToTextEvent
import com.gm.carcontrolsim.gateway.SpeechToTextGateway
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class StartListenerUseCase @Inject constructor(
    private val speechToTextGateway: SpeechToTextGateway,
) {
    fun startSpeechListener(): Response<Boolean> =
        speechToTextGateway.startSpeechToTextEngine()
}
