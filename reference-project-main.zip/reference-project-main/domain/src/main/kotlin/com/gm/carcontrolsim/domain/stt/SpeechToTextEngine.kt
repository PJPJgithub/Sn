package com.gm.carcontrolsim.domain.stt

import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.entity.SpeechToTextEvent
import kotlinx.coroutines.flow.Flow

interface SpeechToTextEngine {
    fun create(): Flow<SpeechToTextEvent>

    fun start(): Response<Boolean>
    fun stop()
}
