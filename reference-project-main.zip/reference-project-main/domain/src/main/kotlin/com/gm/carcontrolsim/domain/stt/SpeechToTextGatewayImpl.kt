package com.gm.carcontrolsim.domain.stt

import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.entity.SpeechToTextEvent
import com.gm.carcontrolsim.gateway.SpeechToTextGateway
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class SpeechToTextGatewayImpl @Inject constructor(
    private val speechToTextEngine: SpeechToTextEngine
) : SpeechToTextGateway {
    override fun createSpeechToTextEngine(): Flow<SpeechToTextEvent> {
        return speechToTextEngine.create()
    }

    override fun startSpeechToTextEngine(): Response<Boolean> {
        return speechToTextEngine.start()
    }

    override fun stopSpeechToTextEngine() {
        return speechToTextEngine.stop()
    }
}
