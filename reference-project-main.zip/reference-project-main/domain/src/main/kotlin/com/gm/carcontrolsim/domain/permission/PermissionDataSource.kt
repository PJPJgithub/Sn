/*
 * Copyright (C) GM Global Technology Operations LLC 2024.
 * All Rights Reserved.
 * GM Confidential Restricted.
 */

package com.gm.carcontrolsim.domain.permission

import com.gm.carcontrolsim.entity.PermissionStatus

interface PermissionDataSource {
    fun getRecordPermission(): PermissionStatus
}
