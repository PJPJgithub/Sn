package com.gm.carcontrolsim.usecase.stt

import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.entity.SpeechToTextEvent
import com.gm.carcontrolsim.gateway.SpeechToTextGateway
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.naming.Context

class CreateSpeechListenerUseCase @Inject constructor(
    private val speechToTextGateway: SpeechToTextGateway,
) {
    fun createSpeechListener(): Flow<SpeechToTextEvent> =
        speechToTextGateway.createSpeechToTextEngine()
}
