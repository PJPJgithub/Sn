package com.gm.carcontrolsim.gateway

import com.gm.carcontrolsim.entity.PermissionStatus
import com.gm.carcontrolsim.entity.Response
import kotlinx.coroutines.flow.Flow

interface RecordPermissionGateway {

    // This is just sample code to show how to use Kotlin Flow in Gateway pattern.
    fun getRecordPermissionStatusWithFlow(): Flow<Response<PermissionStatus>>

    fun getRecordPermissionStatus(): Response<PermissionStatus>
}
