package com.gm.carcontrolsim.usecase.stt

class StopListenerUseCase {
}
