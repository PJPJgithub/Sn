package com.gm.carcontrolsim.domain.permission

import com.gm.carcontrolsim.entity.PermissionStatus
import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.gateway.RecordPermissionGateway
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class RecordPermissionGatewayImpl @Inject constructor(
    private val androidPermissionDataSource: AndroidPermissionDataSource
) : RecordPermissionGateway {
    override fun getRecordPermissionStatusWithFlow(): Flow<Response<PermissionStatus>> {
        TODO("Not yet implemented")
    }

    override fun getRecordPermissionStatus(): Response<PermissionStatus> {
        return Response.Success(androidPermissionDataSource.getRecordPermission())
    }
}
