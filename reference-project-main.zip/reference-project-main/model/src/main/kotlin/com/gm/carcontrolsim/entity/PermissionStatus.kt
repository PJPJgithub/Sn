package com.gm.carcontrolsim.entity

data class PermissionStatus(
    val permission: String = "",
    val granted: Boolean = false,
    val value: Int = 0,
)
