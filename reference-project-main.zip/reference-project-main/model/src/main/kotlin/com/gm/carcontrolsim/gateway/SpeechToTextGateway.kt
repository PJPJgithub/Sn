package com.gm.carcontrolsim.gateway

import com.gm.carcontrolsim.entity.Response
import com.gm.carcontrolsim.entity.SpeechToTextEvent
import kotlinx.coroutines.flow.Flow

interface SpeechToTextGateway {
    fun createSpeechToTextEngine(): Flow<SpeechToTextEvent>
    fun startSpeechToTextEngine(): Response<Boolean>
    fun stopSpeechToTextEngine()
}
