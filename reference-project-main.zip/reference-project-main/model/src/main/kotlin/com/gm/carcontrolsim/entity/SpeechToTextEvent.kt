package com.gm.carcontrolsim.entity

 sealed class SpeechToTextEvent {
     abstract val status: StatusType

     class ReadyToSpeech() : SpeechToTextEvent() {
         override val status: StatusType
             get() = StatusType.STARTED
     }

     class BeginingOfSpeech() : SpeechToTextEvent() {
         override val status: StatusType
             get() = StatusType.STARTED
     }

     class EndOfSpeech() : SpeechToTextEvent() {
         override val status: StatusType
             get() = StatusType.STARTED
     }

     data class SpeechResult(val text: String) : SpeechToTextEvent() {
         override val status: StatusType
             get() = StatusType.STARTED
     }

     enum class StatusType {
         STOPED,
         STARTED,
     }
 }
